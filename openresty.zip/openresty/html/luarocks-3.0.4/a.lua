local cjson = require "cjson"
local elastic = require "resty.elasticsearch.client"
local redis = require "resty.redis"

local request_method = ngx.var.request_method
local args = nil
--获取参数的值
if "GET" == request_method then
    args = ngx.req.get_uri_args()
elseif "POST" == request_method then
    ngx.req.read_body()
    args = ngx.req.get_post_args()
end

for k, v in pairs(args) do
    ngx.say(k..":"..v)
end

must_str = {}

for k, v in pairs(args) do 
    if k == "name" then
         sub_query_str = {
             wildcard = { name = "*"..args["name"].."*" } 
         }
         ngx.say(1111)
         table.insert(must_str, sub_query_str)
    end
    if k == "status" then
        sub_query_str = {
            term = { status = args["status"] }
        }
        ngx.say(2222)
        table.insert(must_str, sub_query_str)
    end
end

ngx.say(cjson.encode(must_str))

local el = elastic:new({
  { host = "10.30.176.216", port = 9201 },
  --{ host = "192.168.0.1", port = 9200 }
})
el:index('zk_user_works')
el:type('work')

local ok, err = el:count()
if ok then
  ngx.say(ok)
else 
  ngx.say(err)
end


query_str = {
    query = {
        bool = {
            must = must_str
        }
    }
}
ngx.say(cjson.encode(query_str))

local res, err = el:search(query_str)
if res then
  ngx.say(res)
  res = cjson.decode(res)
  total = res["hits"]["total"]
  if total == 0 then
      ngx.say("find total 0")
  else
      ngx.say("find total "..total)
  end
  data = res["hits"]["hits"]
  --ngx.say(type(data))
  for k, v in pairs(data) do
      ngx.say(type(v))
      --v = cjson.encode(v)
      source = v["_source"]
      ngx.say(source["name"])
      ngx.log(ngx.ERR, source["name"])
      --for k1, v1 in pairs(v) do
        --  ngx.say(type(k1))
      --end
  end
else 
  ngx.say(err)
end
 
--local http = require "socket.http"
