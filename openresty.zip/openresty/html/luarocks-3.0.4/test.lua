local cjson = require("cjson")
function subQuery(_type, key, value)
    term = {}
    if _type == "term" then 
	term["term"] = "aaa"
        return term
    end
    if _type == "wildcard" then 
	return { wildcard = _tmp }
    end
end

t = subQuery("term", "name", "cokd")
 
--for k,v in pairs(t) doend

print(cjson.encode(t))
