-- Requiring all endpoint related test modules
require "endpoints.TasksTest.CancelTest"
require "endpoints.TasksTest.GetTest"
