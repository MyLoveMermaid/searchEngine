#!/bin/bash

wget https://dhavalkapil.com/elasticsearch-test-dataset/dataset/2015-01-01-15.json.gz
gunzip 2015-01-01-15.json.gz
