-- Requiring all connection pool related test modules
require "connectionpool.StaticConnectionPoolTest"
