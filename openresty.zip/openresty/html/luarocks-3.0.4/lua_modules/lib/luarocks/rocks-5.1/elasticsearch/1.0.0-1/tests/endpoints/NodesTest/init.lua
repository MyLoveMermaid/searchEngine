-- Requiring all endpoint related test modules
require "endpoints.NodesTest.NodesEndpointTest"

require "endpoints.NodesTest.HotThreadsTest"
require "endpoints.NodesTest.InfoTest"
require "endpoints.NodesTest.ShutdownTest"
require "endpoints.NodesTest.StatsTest"
