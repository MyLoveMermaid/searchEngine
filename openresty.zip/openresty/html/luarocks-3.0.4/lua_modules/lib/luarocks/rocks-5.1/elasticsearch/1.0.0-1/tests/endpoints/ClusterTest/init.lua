-- Requiring all endpoint related test modules
require "endpoints.ClusterTest.GetSettingsTest"
require "endpoints.ClusterTest.HealthTest"
require "endpoints.ClusterTest.PendingTasksTest"
require "endpoints.ClusterTest.PutSettingsTest"
require "endpoints.ClusterTest.RerouteTest"
require "endpoints.ClusterTest.StateTest"
require "endpoints.ClusterTest.StatsTest"
